import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TableusersPage } from './tableusers';

@NgModule({
  declarations: [
    TableusersPage,
  ],
  imports: [
    IonicPageModule.forChild(TableusersPage),
  ],
  exports: [
    TableusersPage
  ]
})
export class TableusersPageModule {}
